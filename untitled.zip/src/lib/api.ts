import { 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp, 
  collection, 
  query, 
  where, 
  getDocs, 
  orderBy, 
  limit as firestoreLimit, 
  deleteDoc, 
  writeBatch 
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { 
  UserPermissions, 
  Proposal, 
  Workout, 
  MutationAuditLog, 
  Thread, 
  ThreadMessage, 
  AutonomyLevel,
  ProposalStatus,
  BodyweightEntry,
  PersonalRecord,
  UserProfile,
  Target1RM
} from '../types';

// ==========================================
// USER PERMISSIONS
// ==========================================

export async function getUserPermissions(userId: string): Promise<UserPermissions> {
  try {
    const docRef = doc(db, 'user_permissions', userId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as UserPermissions;
    }
  } catch (e) {
    console.warn("Could not fetch user_permissions from Firestore, fallback to local:", e);
  }
  
  // Default permissions
  const defaultPermissions: UserPermissions = {
    userId,
    autonomyLevel: 'L2_GUIDED_AUTONOMY',
    permissionEpoch: 1
  };
  
  try {
    await setDoc(doc(db, 'user_permissions', userId), defaultPermissions);
  } catch (err) {
    // Ignore if offline
  }
  
  return defaultPermissions;
}

export async function updateUserPermissions(
  userId: string, 
  autonomyLevel: AutonomyLevel
): Promise<UserPermissions> {
  const current = await getUserPermissions(userId);
  const updated: UserPermissions = {
    userId,
    autonomyLevel,
    permissionEpoch: (current.permissionEpoch || 1) + 1
  };

  try {
    await setDoc(doc(db, 'user_permissions', userId), updated);
  } catch (e) {
    console.warn("Could not update Firestore user_permissions:", e);
  }

  localStorage.setItem(`forge_permissions_${userId}`, JSON.stringify(updated));
  return updated;
}

// ==========================================
// WORKOUTS & OPTIMISTIC CONCURRENCY CONTROL (OCC)
// ==========================================

export async function getWorkouts(userId: string): Promise<Workout[]> {
  try {
    const q = query(
      collection(db, 'workouts'),
      where('userId', '==', userId),
      orderBy('scheduledDate', 'desc')
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Workout));
    }
  } catch (e) {
    console.warn("Firestore query failed for workouts, reading localStorage:", e);
  }

  const local = localStorage.getItem(`forge_workouts_${userId}`);
  if (local) {
    try {
      return JSON.parse(local);
    } catch (e) {}
  }
  return [];
}

export async function getWorkout(workoutId: string, userId: string): Promise<Workout | null> {
  try {
    const docRef = doc(db, 'workouts', workoutId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return { id: snap.id, ...snap.data() } as Workout;
    }
  } catch (e) {
    console.warn("Could not fetch workout from Firestore:", e);
  }

  const list = await getWorkouts(userId);
  return list.find(w => w.id === workoutId) || null;
}

export async function saveWorkout(
  workout: Workout,
  actor: 'USER' | 'AI_BRAIN' | 'SYSTEM_AUTONOMOUS' = 'USER',
  summary: string = 'Updated workout sets and details'
): Promise<Workout> {
  const current = await getWorkout(workout.id, workout.userId || 'default');
  const baseVersion = current ? current.version : 0;
  const resultVersion = baseVersion + 1;

  const updatedWorkout: Workout = {
    ...workout,
    version: resultVersion,
    updatedAt: new Date().toISOString()
  };

  // 1. Write workout to Firestore
  try {
    await setDoc(doc(db, 'workouts', workout.id), updatedWorkout);
  } catch (e) {
    console.warn("Firestore saveWorkout failed, saving locally:", e);
  }

  // 2. Update localStorage cache
  if (workout.userId) {
    const all = await getWorkouts(workout.userId);
    const exists = all.some(w => w.id === workout.id);
    const nextList = exists 
      ? all.map(w => w.id === workout.id ? updatedWorkout : w)
      : [updatedWorkout, ...all];
    localStorage.setItem(`forge_workouts_${workout.userId}`, JSON.stringify(nextList));
  }

  // 3. Create Mutation Audit Log with inverse delta for rollback
  if (workout.userId) {
    const inverseDelta = current ? {
      title: current.title,
      scheduledDate: current.scheduledDate,
      status: current.status,
      sets: current.sets
    } : { deleted: true };

    await recordMutationAuditLog({
      id: crypto.randomUUID(),
      mutationId: crypto.randomUUID(),
      userId: workout.userId,
      actor,
      targetEntityType: 'WORKOUT',
      targetEntityId: workout.id,
      baseVersion,
      resultVersion,
      summary,
      inverseDelta,
      createdAt: new Date().toISOString()
    });
  }

  return updatedWorkout;
}

export async function deleteWorkout(
  workoutId: string, 
  userId: string,
  actor: 'USER' | 'AI_BRAIN' = 'USER'
): Promise<void> {
  const current = await getWorkout(workoutId, userId);

  // 1. Delete from Firestore
  try {
    await deleteDoc(doc(db, 'workouts', workoutId));
  } catch (e) {
    console.warn("Firestore deleteWorkout failed, deleting locally:", e);
  }

  // 2. Remove from localStorage cache
  const all = await getWorkouts(userId);
  const nextList = all.filter(w => w.id !== workoutId);
  localStorage.setItem(`forge_workouts_${userId}`, JSON.stringify(nextList));

  // 3. Record Audit Log with inverse delta for restoring if needed
  if (current) {
    await recordMutationAuditLog({
      id: crypto.randomUUID(),
      mutationId: crypto.randomUUID(),
      userId,
      actor,
      targetEntityType: 'WORKOUT',
      targetEntityId: workoutId,
      baseVersion: current.version,
      resultVersion: current.version + 1,
      summary: `Deleted workout: "${current.title}"`,
      inverseDelta: {
        title: current.title,
        scheduledDate: current.scheduledDate,
        status: current.status,
        sets: current.sets,
        version: current.version
      },
      createdAt: new Date().toISOString()
    });
  }
}

// ==========================================
// PROPOSALS MANAGEMENT & OCC EXECUTION
// ==========================================

export async function getProposals(userId: string): Promise<Proposal[]> {
  try {
    const q = query(
      collection(db, 'proposals'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Proposal));
    }
  } catch (e) {
    console.warn("Could not fetch proposals from Firestore:", e);
  }

  const local = localStorage.getItem(`forge_proposals_${userId}`);
  if (local) {
    try {
      return JSON.parse(local);
    } catch (e) {}
  }
  return [];
}

export async function createProposal(userId: string, proposal: Omit<Proposal, 'createdAt'>): Promise<Proposal> {
  const newProposal: Proposal = {
    ...proposal,
    createdAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'proposals', proposal.id), { ...newProposal, userId });
  } catch (e) {
    console.warn("Could not save proposal to Firestore:", e);
  }

  const list = await getProposals(userId);
  const updated = [newProposal, ...list.filter(p => p.id !== proposal.id)];
  localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(updated));

  return newProposal;
}

export async function executeProposal(
  proposalId: string, 
  userId: string,
  actor: 'USER' | 'AI_BRAIN' | 'SYSTEM_AUTONOMOUS' = 'USER'
): Promise<{ success: boolean; workout?: Workout; proposal?: Proposal; error?: string }> {
  const proposals = await getProposals(userId);
  const proposal = proposals.find(p => p.id === proposalId);
  if (!proposal) {
    return { success: false, error: "Proposal not found" };
  }

  // 1. Fetch live workout
  const liveWorkout = await getWorkout(proposal.targetEntityId, userId);
  if (!liveWorkout) {
    return { success: false, error: "Target workout does not exist" };
  }

  // 2. OCC Verification: Check if workout version matches proposal's baseVersion
  if (liveWorkout.version !== proposal.baseVersion) {
    // CONFLICT: Target was modified concurrently!
    const conflictProposal: Proposal = {
      ...proposal,
      status: 'REJECTED_CONFLICT',
      reviewedAt: new Date().toISOString()
    };
    try {
      await setDoc(doc(db, 'proposals', proposal.id), { ...conflictProposal, userId });
    } catch (e) {}
    const nextList = proposals.map(p => p.id === proposal.id ? conflictProposal : p);
    localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(nextList));

    return {
      success: false,
      proposal: conflictProposal,
      error: `Optimistic Concurrency Conflict: Target workout has evolved to v${liveWorkout.version} (proposal was based on v${proposal.baseVersion}). Please rebase.`
    };
  }

  // 3. Apply changes with OCC increment
  const updatedWorkout: Workout = {
    ...liveWorkout,
    ...proposal.afterState,
    id: liveWorkout.id,
    userId: liveWorkout.userId,
    version: liveWorkout.version + 1,
    updatedAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'workouts', liveWorkout.id), updatedWorkout);
  } catch (e) {}

  // Update proposals status to EXECUTED
  const executedProposal: Proposal = {
    ...proposal,
    status: 'EXECUTED',
    reviewedAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'proposals', proposal.id), { ...executedProposal, userId });
  } catch (e) {}

  // Record audit log
  const inverseDelta = {
    title: liveWorkout.title,
    scheduledDate: liveWorkout.scheduledDate,
    status: liveWorkout.status,
    sets: liveWorkout.sets
  };

  await recordMutationAuditLog({
    id: crypto.randomUUID(),
    mutationId: crypto.randomUUID(),
    userId,
    actor,
    targetEntityType: 'WORKOUT',
    targetEntityId: liveWorkout.id,
    baseVersion: proposal.baseVersion,
    resultVersion: updatedWorkout.version,
    summary: `Executed AI Proposal: ${proposal.summary}`,
    inverseDelta,
    createdAt: new Date().toISOString()
  });

  // Local storage update
  const allWorkouts = await getWorkouts(userId);
  localStorage.setItem(`forge_workouts_${userId}`, JSON.stringify(
    allWorkouts.map(w => w.id === updatedWorkout.id ? updatedWorkout : w)
  ));

  const allProposals = proposals.map(p => p.id === proposal.id ? executedProposal : p);
  localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(allProposals));

  return { success: true, workout: updatedWorkout, proposal: executedProposal };
}

export async function discardProposal(proposalId: string, userId: string): Promise<Proposal | null> {
  const proposals = await getProposals(userId);
  const proposal = proposals.find(p => p.id === proposalId);
  if (!proposal) return null;

  const discarded: Proposal = {
    ...proposal,
    status: 'DISCARDED',
    reviewedAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'proposals', proposal.id), { ...discarded, userId });
  } catch (e) {}

  const nextList = proposals.map(p => p.id === proposal.id ? discarded : p);
  localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(nextList));

  return discarded;
}

// ==========================================
// MUTATION AUDIT LOGS & REVERSIBLE UNDO
// ==========================================

export async function getMutationAuditLogs(userId: string, targetEntityId?: string): Promise<MutationAuditLog[]> {
  try {
    let q = query(
      collection(db, 'mutation_audit_logs'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    if (targetEntityId) {
      q = query(
        collection(db, 'mutation_audit_logs'),
        where('userId', '==', userId),
        where('targetEntityId', '==', targetEntityId),
        orderBy('createdAt', 'desc')
      );
    }
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as MutationAuditLog));
    }
  } catch (e) {
    console.warn("Could not fetch audit logs from Firestore:", e);
  }

  const local = localStorage.getItem(`forge_audit_logs_${userId}`);
  if (local) {
    try {
      const parsed: MutationAuditLog[] = JSON.parse(local);
      if (targetEntityId) {
        return parsed.filter(l => l.targetEntityId === targetEntityId);
      }
      return parsed;
    } catch (e) {}
  }
  return [];
}

export async function recordMutationAuditLog(log: MutationAuditLog): Promise<void> {
  try {
    await setDoc(doc(db, 'mutation_audit_logs', log.id), log);
  } catch (e) {
    console.warn("Could not record audit log to Firestore:", e);
  }

  if (log.userId) {
    const list = await getMutationAuditLogs(log.userId);
    const updated = [log, ...list.filter(l => l.id !== log.id)];
    localStorage.setItem(`forge_audit_logs_${log.userId}`, JSON.stringify(updated));
  }
}

export async function undoMutation(
  auditLogId: string, 
  userId: string
): Promise<{ success: boolean; workout?: Workout; error?: string }> {
  const logs = await getMutationAuditLogs(userId);
  const log = logs.find(l => l.id === auditLogId);
  if (!log) return { success: false, error: "Audit log entry not found" };

  const workout = await getWorkout(log.targetEntityId, userId);
  if (!workout) return { success: false, error: "Target workout not found" };

  // Contiguous OCC check: verify workout is currently at resultVersion
  if (workout.version !== log.resultVersion) {
    return {
      success: false,
      error: `Non-contiguous rollback rejected: Workout is currently at v${workout.version}, but this mutation resulted in v${log.resultVersion}. You can only undo the latest contiguous step.`
    };
  }

  // Restore previous snapshot from inverse delta
  const restoredWorkout: Workout = {
    ...workout,
    ...log.inverseDelta,
    id: workout.id,
    userId: workout.userId,
    version: workout.version + 1, // OCC monotonically increases
    updatedAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'workouts', workout.id), restoredWorkout);
  } catch (e) {}

  // Record undo in audit log
  await recordMutationAuditLog({
    id: crypto.randomUUID(),
    mutationId: crypto.randomUUID(),
    userId,
    actor: 'USER',
    targetEntityType: 'WORKOUT',
    targetEntityId: workout.id,
    baseVersion: workout.version,
    resultVersion: restoredWorkout.version,
    summary: `Undid mutation (${log.summary}) — restored state from v${log.baseVersion}`,
    inverseDelta: {
      title: workout.title,
      scheduledDate: workout.scheduledDate,
      status: workout.status,
      sets: workout.sets
    },
    createdAt: new Date().toISOString()
  });

  const allWorkouts = await getWorkouts(userId);
  localStorage.setItem(`forge_workouts_${userId}`, JSON.stringify(
    allWorkouts.map(w => w.id === restoredWorkout.id ? restoredWorkout : w)
  ));

  return { success: true, workout: restoredWorkout };
}

// ==========================================
// THREADS & COPILOT CHATS
// ==========================================

export async function getThreads(userId: string): Promise<Thread[]> {
  try {
    const q = query(
      collection(db, 'threads'),
      where('userId', '==', userId),
      orderBy('updatedAt', 'desc')
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Thread));
    }
  } catch (e) {
    console.warn("Could not fetch threads from Firestore:", e);
  }

  const local = localStorage.getItem(`forge_threads_${userId}`);
  if (local) {
    try {
      return JSON.parse(local);
    } catch (e) {}
  }
  return [];
}

export async function createThread(userId: string, title: string, targetWorkoutId?: string): Promise<Thread> {
  const newThread: Thread = {
    id: crypto.randomUUID(),
    userId,
    title,
    status: 'ACTIVE',
    targetWorkoutId,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [
      {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `Hi! I'm FORGE Brain, your AI fitness copilot. I can inspect your training logs, evaluate progressive overload, and formulate structured proposals for you to review and approve with Optimistic Concurrency Control (OCC). What would you like to work on?`,
        timestamp: new Date().toISOString()
      }
    ]
  };

  try {
    await setDoc(doc(db, 'threads', newThread.id), newThread);
  } catch (e) {}

  const threads = await getThreads(userId);
  localStorage.setItem(`forge_threads_${userId}`, JSON.stringify([newThread, ...threads]));
  return newThread;
}

export async function saveThread(thread: Thread): Promise<void> {
  try {
    await setDoc(doc(db, 'threads', thread.id), thread);
  } catch (e) {}

  const threads = await getThreads(thread.userId);
  const updated = threads.some(t => t.id === thread.id)
    ? threads.map(t => t.id === thread.id ? thread : t)
    : [thread, ...threads];
  localStorage.setItem(`forge_threads_${thread.userId}`, JSON.stringify(updated));
}

export async function deleteThread(threadId: string, userId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'threads', threadId));
  } catch (e) {
    console.warn("Firestore deleteThread failed, deleting locally:", e);
  }

  const threads = await getThreads(userId);
  const updated = threads.filter(t => t.id !== threadId);
  localStorage.setItem(`forge_threads_${userId}`, JSON.stringify(updated));
}

export async function deleteAllThreads(userId: string): Promise<void> {
  const threads = await getThreads(userId);
  for (const t of threads) {
    try {
      await deleteDoc(doc(db, 'threads', t.id));
    } catch (e) {}
  }
  localStorage.removeItem(`forge_threads_${userId}`);
}

// ==========================================
// COMPATIBILITY & ANALYTICS EXPORTS
// ==========================================

export async function getRecentWorkouts(userId: string, limitCount: number = 10): Promise<any[]> {
  const workouts = await getWorkouts(userId);
  return workouts.slice(0, limitCount).map(w => ({
    ...w,
    name: w.title,
    startedAt: new Date(w.scheduledDate).getTime(),
    completedAt: new Date(w.scheduledDate).getTime() + 3600000,
    totalVolume: (w.sets || []).reduce((sum, s) => sum + (s.weight * s.reps), 0),
    exercises: (w.sets || []).map(s => ({
      id: s.id,
      exerciseId: s.exercise.toLowerCase().replace(/\s+/g, '-'),
      sets: [{ id: s.id, weight: s.weight, reps: s.reps, completed: true }]
    }))
  }));
}

export async function getBodyweight(userId: string): Promise<BodyweightEntry[]> {
  try {
    const q = query(collection(db, 'bodyweight'), where('userId', '==', userId), orderBy('date', 'desc'));
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as BodyweightEntry));
    }
  } catch (e) {}
  const local = localStorage.getItem(`forge_bw_${userId}`);
  return local ? JSON.parse(local) : [
    { id: 'bw1', userId, weight: 78.5, date: Date.now() - 86400000 * 3 },
    { id: 'bw2', userId, weight: 78.2, date: Date.now() - 86400000 * 7 }
  ];
}

export async function saveBodyweight(entry: BodyweightEntry): Promise<void> {
  try {
    await setDoc(doc(db, 'bodyweight', entry.id), entry);
  } catch (e) {}
  const all = await getBodyweight(entry.userId);
  localStorage.setItem(`forge_bw_${entry.userId}`, JSON.stringify([entry, ...all]));
}

// ==========================================
// TARGET 1RM GOALS
// ==========================================

export async function getTarget1RMs(userId: string): Promise<Target1RM[]> {
  try {
    const q = query(
      collection(db, 'target_1rms'),
      where('userId', '==', userId)
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Target1RM));
    }
  } catch (e) {
    console.warn("Could not fetch target_1rms from Firestore, reading local:", e);
  }

  const local = localStorage.getItem(`forge_target_1rms_${userId}`);
  if (local) {
    try {
      return JSON.parse(local);
    } catch (e) {}
  }

  // Default seed target 1RMs for a motivating experience
  const defaultTargets: Target1RM[] = [
    {
      id: `target_bench_${userId}`,
      userId,
      exerciseId: 'bench_press',
      exerciseName: 'Bench Press',
      target1RM: 100,
      createdAt: Date.now() - 86400000 * 7,
      updatedAt: Date.now() - 86400000 * 7,
      notes: 'Road to 100kg (2 plates)'
    },
    {
      id: `target_squat_${userId}`,
      userId,
      exerciseId: 'squat',
      exerciseName: 'Squat',
      target1RM: 140,
      createdAt: Date.now() - 86400000 * 7,
      updatedAt: Date.now() - 86400000 * 7,
      notes: '3 plates milestone'
    },
    {
      id: `target_ohp_${userId}`,
      userId,
      exerciseId: 'overhead_press',
      exerciseName: 'Overhead Press',
      target1RM: 60,
      createdAt: Date.now() - 86400000 * 7,
      updatedAt: Date.now() - 86400000 * 7,
      notes: 'Bodyweight overhead press goal'
    }
  ];

  localStorage.setItem(`forge_target_1rms_${userId}`, JSON.stringify(defaultTargets));
  for (const t of defaultTargets) {
    try {
      await setDoc(doc(db, 'target_1rms', t.id), t);
    } catch (e) {}
  }
  return defaultTargets;
}

export async function saveTarget1RM(target: Target1RM): Promise<Target1RM> {
  const updated: Target1RM = {
    ...target,
    updatedAt: Date.now()
  };

  try {
    await setDoc(doc(db, 'target_1rms', updated.id), updated);
  } catch (e) {
    console.warn("Could not save target 1RM to Firestore, saving locally:", e);
  }

  const all = await getTarget1RMs(updated.userId);
  const exists = all.some(t => t.id === updated.id);
  const nextList = exists
    ? all.map(t => t.id === updated.id ? updated : t)
    : [updated, ...all];

  localStorage.setItem(`forge_target_1rms_${updated.userId}`, JSON.stringify(nextList));
  return updated;
}

export async function deleteTarget1RM(targetId: string, userId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'target_1rms', targetId));
  } catch (e) {
    console.warn("Could not delete target 1RM from Firestore:", e);
  }

  const all = await getTarget1RMs(userId);
  const nextList = all.filter(t => t.id !== targetId);
  localStorage.setItem(`forge_target_1rms_${userId}`, JSON.stringify(nextList));
}

export async function getPlans(userId: string): Promise<any[]> {
  try {
    const q = query(collection(db, 'plans'), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {}
  const local = localStorage.getItem(`forge_plans_${userId}`);
  return local ? JSON.parse(local) : [];
}

export async function savePlan(plan: any): Promise<void> {
  try {
    await setDoc(doc(db, 'plans', plan.id), plan);
  } catch (e) {}
  const all = await getPlans(plan.userId);
  localStorage.setItem(`forge_plans_${plan.userId}`, JSON.stringify([plan, ...all.filter(p => p.id !== plan.id)]));
}

export async function deletePlan(planId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'plans', planId));
  } catch (e) {}
}

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  try {
    const snap = await getDoc(doc(db, 'users', userId));
    if (snap.exists()) return snap.data() as UserProfile;
  } catch (e) {}
  return { userId, name: 'Athlete', experience: 'intermediate', createdAt: Date.now() };
}

export async function saveUserProfile(profile: UserProfile): Promise<void> {
  try {
    await setDoc(doc(db, 'users', profile.userId), profile);
  } catch (e) {}
}

export async function getPersonalRecords(userId: string): Promise<PersonalRecord[]> {
  try {
    const q = query(collection(db, 'personal_records'), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) return snap.docs.map(d => ({ id: d.id, ...d.data() } as PersonalRecord));
  } catch (e) {}
  return [];
}

export async function getPreviousPerformance(userId: string, exerciseId: string): Promise<any | null> {
  const workouts = await getRecentWorkouts(userId, 30);
  const normId = exerciseId.toLowerCase().replace(/[-_\s]+/g, '');
  
  for (const w of workouts) {
    if (w.status !== 'COMPLETED' && w.status !== 'completed') continue;

    // Check exercises array
    if (w.exercises && Array.isArray(w.exercises)) {
      const match = w.exercises.find((e: any) => {
        const eId = (e.exerciseId || '').toLowerCase().replace(/[-_\s]+/g, '');
        return eId === normId || eId.includes(normId) || normId.includes(eId);
      });
      if (match) return w;
    }

    // Check flat sets array
    if (w.sets && Array.isArray(w.sets)) {
      const match = w.sets.find((s: any) => {
        const sEx = (s.exercise || '').toLowerCase().replace(/[-_\s]+/g, '');
        return sEx === normId || sEx.includes(normId) || normId.includes(sEx);
      });
      if (match) return w;
    }
  }
  return null;
}

export async function savePersonalRecord(record: PersonalRecord): Promise<void> {
  try {
    await setDoc(doc(db, 'personal_records', record.id), record);
  } catch (e) {}
}

// ==========================================
// SEED INITIAL DEMO DATA
// ==========================================

export async function seedForgeData(userId: string): Promise<void> {
  const today = new Date();
  const dateStr = today.toISOString().split('T')[0];
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  const nextDay = new Date(today);
  nextDay.setDate(nextDay.getDate() + 3);
  const nextDayStr = nextDay.toISOString().split('T')[0];

  const initialWorkouts: Workout[] = [
    {
      id: `w_upper_${userId}`,
      userId,
      title: 'Upper Body Power & Hypertrophy',
      scheduledDate: dateStr,
      status: 'PLANNED',
      version: 1,
      sets: [
        { id: 's1', exercise: 'Barbell Bench Press', reps: 8, weight: 80, completed: false },
        { id: 's2', exercise: 'Barbell Bench Press', reps: 8, weight: 80, completed: false },
        { id: 's3', exercise: 'Barbell Bench Press', reps: 8, weight: 80, completed: false },
        { id: 's4', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's5', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's6', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's7', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's8', exercise: 'Lateral Raises', reps: 15, weight: 12, completed: false },
        { id: 's9', exercise: 'Tricep Rope Pushdown', reps: 12, weight: 25, completed: false }
      ],
      updatedAt: new Date().toISOString()
    },
    {
      id: `w_lower_${userId}`,
      userId,
      title: 'Lower Body Strength & Quads',
      scheduledDate: tomorrowStr,
      status: 'PLANNED',
      version: 1,
      sets: [
        { id: 'l1', exercise: 'Barbell Squat', reps: 6, weight: 110, completed: false },
        { id: 'l2', exercise: 'Barbell Squat', reps: 6, weight: 110, completed: false },
        { id: 'l3', exercise: 'Barbell Squat', reps: 6, weight: 110, completed: false },
        { id: 'l4', exercise: 'Romanian Deadlift', reps: 8, weight: 95, completed: false },
        { id: 'l5', exercise: 'Romanian Deadlift', reps: 8, weight: 95, completed: false },
        { id: 'l6', exercise: 'Leg Press', reps: 12, weight: 160, completed: false },
        { id: 'l7', exercise: 'Standing Calf Raise', reps: 15, weight: 60, completed: false }
      ],
      updatedAt: new Date().toISOString()
    },
    {
      id: `w_pull_${userId}`,
      userId,
      title: 'Pull & Posterior Chain',
      scheduledDate: nextDayStr,
      status: 'PLANNED',
      version: 1,
      sets: [
        { id: 'p1', exercise: 'Deadlift', reps: 5, weight: 140, completed: false },
        { id: 'p2', exercise: 'Deadlift', reps: 5, weight: 140, completed: false },
        { id: 'p3', exercise: 'Lat Pulldown', reps: 10, weight: 65, completed: false },
        { id: 'p4', exercise: 'Seated Cable Row', reps: 10, weight: 60, completed: false },
        { id: 'p5', exercise: 'Incline Dumbbell Curl', reps: 12, weight: 14, completed: false },
        { id: 'p6', exercise: 'Face Pulls', reps: 15, weight: 20, completed: false }
      ],
      updatedAt: new Date().toISOString()
    }
  ];

  for (const w of initialWorkouts) {
    try {
      await setDoc(doc(db, 'workouts', w.id), w);
    } catch (e) {}
  }
  localStorage.setItem(`forge_workouts_${userId}`, JSON.stringify(initialWorkouts));

  // Seed default thread
  const threadId = `th_seed_${userId}`;
  const seedProposal: Proposal = {
    id: `prop_seed_${userId}`,
    threadId,
    targetEntityType: 'WORKOUT',
    targetEntityId: initialWorkouts[0].id,
    baseVersion: 1,
    status: 'PENDING_APPROVAL',
    summary: 'Progressive Overload: +2.5kg on Bench Press (80kg -> 82.5kg) & +1 set on Lateral Raises for shoulder volume ramp',
    beforeState: {
      title: initialWorkouts[0].title,
      scheduledDate: initialWorkouts[0].scheduledDate,
      status: initialWorkouts[0].status,
      sets: initialWorkouts[0].sets
    },
    afterState: {
      title: initialWorkouts[0].title,
      scheduledDate: initialWorkouts[0].scheduledDate,
      status: initialWorkouts[0].status,
      sets: [
        { id: 's1', exercise: 'Barbell Bench Press', reps: 8, weight: 82.5, completed: false },
        { id: 's2', exercise: 'Barbell Bench Press', reps: 8, weight: 82.5, completed: false },
        { id: 's3', exercise: 'Barbell Bench Press', reps: 8, weight: 82.5, completed: false },
        { id: 's4', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's5', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's6', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's7', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's8', exercise: 'Lateral Raises', reps: 15, weight: 12, completed: false },
        { id: 's8_b', exercise: 'Lateral Raises', reps: 15, weight: 12, completed: false },
        { id: 's9', exercise: 'Tricep Rope Pushdown', reps: 12, weight: 25, completed: false }
      ]
    },
    createdAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'proposals', seedProposal.id), { ...seedProposal, userId });
  } catch (e) {}
  localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify([seedProposal]));

  const seedThread: Thread = {
    id: threadId,
    userId,
    title: 'Upper Body Progressive Overload Audit',
    status: 'ACTIVE',
    targetWorkoutId: initialWorkouts[0].id,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [
      {
        id: 'm1',
        role: 'user',
        content: 'Can you analyze my upper body workout and recommend progressive overload adjustments?',
        timestamp: new Date(Date.now() - 300000).toISOString()
      },
      {
        id: 'm2',
        role: 'assistant',
        content: 'I reviewed your Upper Body session. You completed all 3 sets of 8 reps at 80kg on Bench Press comfortably last session. Based on your current recovery profile, I propose increasing Bench Press to 82.5kg (+2.5kg overload) and adding a 2nd hypertrophy set of Lateral Raises. Review the proposed diff below:',
        timestamp: new Date().toISOString(),
        proposalId: seedProposal.id,
        proposal: seedProposal
      }
    ]
  };

  try {
    await setDoc(doc(db, 'threads', seedThread.id), seedThread);
  } catch (e) {}
  localStorage.setItem(`forge_threads_${userId}`, JSON.stringify([seedThread]));

  // Seed default User Permissions
  const permissions: UserPermissions = {
    userId,
    autonomyLevel: 'L2_GUIDED_AUTONOMY',
    permissionEpoch: 1
  };
  try {
    await setDoc(doc(db, 'user_permissions', userId), permissions);
  } catch (e) {}

  // Record initial seed mutation audit log
  await recordMutationAuditLog({
    id: `log_seed_${userId}`,
    mutationId: crypto.randomUUID(),
    userId,
    actor: 'SYSTEM_AUTONOMOUS',
    targetEntityType: 'WORKOUT',
    targetEntityId: initialWorkouts[0].id,
    baseVersion: 0,
    resultVersion: 1,
    summary: 'Initialized base workout routine (Upper Body Power & Hypertrophy)',
    inverseDelta: { deleted: true },
    createdAt: new Date().toISOString()
  });
}

export async function mutateWorkout(workoutId: string, baseVersion: number, updates: Partial<Workout>, duration?: number, volume?: number): Promise<Workout> {
  const token = await auth.currentUser?.getIdToken();
  if (!token) throw new Error('Not authenticated');

  const res = await fetch(`/api/workouts/${workoutId}/mutate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ baseVersion, updates, duration, volume })
  });

  const data = await res.json();
  if (!res.ok) {
    if (res.status === 409) {
      const err: any = new Error(data.error || 'Stale version');
      err.status = 409;
      err.currentVersion = data.currentVersion;
      err.workout = data.workout;
      throw err;
    }
    throw new Error(data.error || 'Failed to mutate workout');
  }

  // Update localStorage cache
  if (data.workout && data.workout.userId) {
    const all = await getWorkouts(data.workout.userId);
    const exists = all.some(w => w.id === data.workout.id);
    const nextList = exists 
      ? all.map(w => w.id === data.workout.id ? data.workout : w)
      : [data.workout, ...all];
    localStorage.setItem(`forge_workouts_${data.workout.userId}`, JSON.stringify(nextList));
  }

  return data.workout;
}

