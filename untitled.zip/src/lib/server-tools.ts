import { FunctionDeclaration, Type } from "@google/genai";
import { fetchUserDocs, fetchUserDoc } from './firestore-rest';
import { analyzeExerciseProgression } from './progression';

export function validatePlanArgs(args: any) {
  if (!args.name || typeof args.name !== 'string') throw new Error("Plan name is required and must be a string.");
  if (!args.goal || typeof args.goal !== 'string') throw new Error("Plan goal is required and must be a string.");
  if (!Array.isArray(args.days) || args.days.length === 0) throw new Error("Plan must have at least one day defined in 'days' array.");
  
  for (let i = 0; i < args.days.length; i++) {
    const day = args.days[i];
    if (!day.name || typeof day.name !== 'string') throw new Error(`Day ${i+1} must have a valid string name.`);
    if (!Array.isArray(day.exercises) || day.exercises.length === 0) throw new Error(`Day ${i+1} must have at least one exercise in 'exercises' array.`);
    
    for (let j = 0; j < day.exercises.length; j++) {
      const ex = day.exercises[j];
      if (!ex.exerciseId || typeof ex.exerciseId !== 'string') throw new Error(`Exercise ${j+1} on Day ${i+1} must have a valid exerciseId string.`);
      if (typeof ex.targetSets !== 'number' || ex.targetSets <= 0) throw new Error(`Exercise ${ex.exerciseId} on Day ${i+1} must have targetSets > 0.`);
      if (typeof ex.targetRepsMin !== 'number' || ex.targetRepsMin <= 0) throw new Error(`Exercise ${ex.exerciseId} on Day ${i+1} must have targetRepsMin > 0.`);
      if (typeof ex.targetRepsMax !== 'number' || ex.targetRepsMax < ex.targetRepsMin) throw new Error(`Exercise ${ex.exerciseId} on Day ${i+1} must have targetRepsMax >= targetRepsMin.`);
    }
  }
}

export function validateProposalArgs(args: any) {
  if (!args.targetEntityId || typeof args.targetEntityId !== 'string') throw new Error("targetEntityId is required.");
  if (typeof args.baseVersion !== 'number') throw new Error("baseVersion must be a valid number.");
  if (!args.summary || typeof args.summary !== 'string') throw new Error("summary must be a descriptive string.");
  if (!args.afterState || typeof args.afterState !== 'object') throw new Error("afterState object is required.");
}

export const toolDeclarations: FunctionDeclaration[] = [
  {
    name: "get_user_profile",
    description: "Returns relevant profile information for the authenticated user and their autonomy level.",
    parameters: { type: Type.OBJECT, properties: {} }
  },
  {
    name: "get_workouts",
    description: "Returns the user's scheduled, planned, and completed workouts with their version numbers, dates, and sets.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        limit: { type: Type.INTEGER, description: "Max workouts to return (default 10)" }
      }
    }
  },
  {
    name: "get_recent_workouts",
    description: "Returns recent completed workouts.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        limit: { type: Type.INTEGER, description: "Max number of workouts to return (default 5)" }
      }
    }
  },
  {
    name: "get_exercise_history",
    description: "Returns the user's historical performance for a specific exercise.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        exerciseId: { type: Type.STRING, description: "The ID of the exercise (e.g. bench-press, squat)" }
      },
      required: ["exerciseId"]
    }
  },
  {
    name: "get_progress",
    description: "Returns aggregate progress statistics like workout frequency, total volume, consistency.",
    parameters: { type: Type.OBJECT, properties: {} }
  },
  {
    name: "get_personal_records",
    description: "Returns the user's overall personal records (PRs) across all exercises.",
    parameters: { type: Type.OBJECT, properties: {} }
  },
  {
    name: "get_progression_analysis",
    description: "Runs FORGE's deterministic progression classifier on the user's workout history for a specific exercise or across all recent exercises. Returns status (PROGRESSING, STALLING, REGRESSING, INSUFFICIENT_DATA), e1RM trend, and calculated next session target.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        exerciseId: { type: Type.STRING, description: "The exercise identifier or name to analyze (e.g. 'bench_press', 'squat', 'Barbell Bench Press')" }
      },
      required: ["exerciseId"]
    }
  },
  {
    name: "propose_workout_change",
    description: "Proposes structured modifications to an existing Workout (sets, reps, weight, schedule date, title) for the user to review and approve. Always specify the target workout's baseVersion for OCC.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        targetEntityId: { type: Type.STRING, description: "The ID of the workout to modify" },
        baseVersion: { type: Type.INTEGER, description: "The exact current version of the target workout (OCC counter)" },
        summary: { type: Type.STRING, description: "Clear explanation of what was changed and why (e.g. Progressive overload: +2.5kg on Bench Press)" },
        afterState: {
          type: Type.OBJECT,
          description: "The complete proposed updated state for the workout",
          properties: {
            title: { type: Type.STRING },
            scheduledDate: { type: Type.STRING },
            status: { type: Type.STRING },
            sets: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  exercise: { type: Type.STRING },
                  reps: { type: Type.INTEGER },
                  weight: { type: Type.NUMBER }
                },
                required: ["id", "exercise", "reps", "weight"]
              }
            }
          },
          required: ["title", "scheduledDate", "sets"]
        }
      },
      required: ["targetEntityId", "baseVersion", "summary", "afterState"]
    }
  },
  {
    name: "create_plan",
    description: "Proposes a new structured training plan for the user.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "Name of the plan (e.g. 5-Day Hypertrophy)" },
        goal: { type: Type.STRING, description: "The main goal of the plan" },
        days: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "Name of the day (e.g. Push, Pull, Legs)" },
              exercises: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    exerciseId: { type: Type.STRING, description: "Exercise ID" },
                    targetSets: { type: Type.INTEGER },
                    targetRepsMin: { type: Type.INTEGER },
                    targetRepsMax: { type: Type.INTEGER }
                  },
                  required: ["exerciseId", "targetSets", "targetRepsMin", "targetRepsMax"]
                }
              }
            },
            required: ["name", "exercises"]
          }
        }
      },
      required: ["name", "goal", "days"]
    }
  }
];

export async function executeTool(name: string, args: any, context: { projectId: string, dbId: string, idToken: string, uid: string }) {
  const { projectId, dbId, idToken, uid } = context;

  switch (name) {
    case 'get_user_profile': {
      const profile = await fetchUserDoc(projectId, dbId, idToken, 'users', uid);
      const permissions = await fetchUserDoc(projectId, dbId, idToken, 'user_permissions', uid);
      return { 
        profile: profile || { status: 'default' },
        permissions: permissions || { autonomyLevel: 'L2_GUIDED_AUTONOMY', permissionEpoch: 1 }
      };
    }

    case 'get_workouts': {
      const workouts = await fetchUserDocs(projectId, dbId, idToken, 'workouts', uid, args.limit || 10, 'scheduledDate', 'DESCENDING');
      return { workouts };
    }

    case 'get_recent_workouts':
      const recentWorkouts = await fetchUserDocs(projectId, dbId, idToken, 'workouts', uid, args.limit || 5, 'scheduledDate', 'DESCENDING');
      return { workouts: recentWorkouts };

    case 'get_exercise_history': {
      const history = await fetchUserDocs(projectId, dbId, idToken, 'workouts', uid, 10, 'scheduledDate', 'DESCENDING');
      return {
        exerciseId: args.exerciseId,
        recentWorkouts: history
      };
    }

    case 'get_progress': {
      const workouts = await fetchUserDocs(projectId, dbId, idToken, 'workouts', uid, 30, 'scheduledDate', 'DESCENDING');
      return {
        totalWorkouts: workouts.length,
        workouts: workouts.map((w: any) => ({ id: w.id, title: w.title, date: w.scheduledDate, version: w.version, setsCount: w.sets?.length || 0 }))
      };
    }

    case 'get_personal_records': {
      return {
        status: "ok",
        notes: "PR calculation computed from workout sets."
      };
    }

    case 'get_progression_analysis': {
      const workouts = await fetchUserDocs(projectId, dbId, idToken, 'workouts', uid, 50, 'scheduledDate', 'DESCENDING');
      const analysis = analyzeExerciseProgression(workouts, args.exerciseId);
      return {
        analysis
      };
    }

    default:
      throw new Error(`Tool ${name} not implemented`);
  }
}
