import React from 'react';
import { Button } from '../components/ui/Button';
import { useAuthStore } from '../store/useAuthStore';
import { useThemeStore } from '../store/useThemeStore';
import { auth } from '../lib/firebase';
import { LogOut, Moon, Sun } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';

export default function Profile() {
  const { user } = useAuthStore();
  const { theme, toggleTheme } = useThemeStore();

  const handleSignOut = () => {
    auth.signOut();
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-display font-bold">Profile</h1>
      </header>

      <Card>
        <CardContent className="p-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="h-16 w-16 rounded-full bg-secondary flex items-center justify-center overflow-hidden">
              {user?.photoURL ? (
                <img src={user.photoURL} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <span className="text-2xl font-bold">{user?.email?.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold">{user?.displayName || "Athlete"}</h2>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="font-semibold">Appearance</span>
            <span className="text-sm text-muted-foreground">Toggle light and dark theme</span>
          </div>
          <Button variant="outline" size="icon" onClick={toggleTheme}>
            {theme === 'dark' ? <Moon size={20} /> : <Sun size={20} />}
          </Button>
        </CardContent>
      </Card>
      
      <div className="pt-4 border-t border-border">
        <Button variant="danger" className="w-full flex items-center justify-center gap-2" onClick={handleSignOut}>
          <LogOut size={18} />
          Sign Out
        </Button>
      </div>
    </div>
  );
}
